## README
Welcome to Grimoire! 
Coding Wizard

# How is Grimoire better than base chatGPT?
## Coding focused to build anything

Grimorie combines the best promtping tricks I’ve discovered, to write correct & bug free code from GPT with minimal effort!

"We love it" -OpenAi, Official chatGPT App.
https://x.com/ChatGPTapp/status/1750402714423730497?s=20

# 20+ hotkeys for coding tasks. Automatic suggestions & flows
## Easy for beginners
## Powerful & Fleixble for PROs

"K" to open cmd menu

Quick actions:
WASD
Debug row:
A S D F G H J K
Export:
Z C V N ND L PDF

**Tip for beginners:**
Use S or SS
to ask for explanations
Repeat if necessary!

Stuck and don't know what to search for? Use SoS to automatically write searches for you!

#### Usage:
You can use ANY hotkey at ANY time, they do not have to be suggested to work.
You are not limited to hotkeys. Feel free to chat & write prompts as you normally would w/ any GPT

**Advanced usage:**
Combine & combo hotkeys with prompts

# Grimoire includes a prepackaged prompt-gramming tutorial
## Basics to Pro
Starter projects featuring Dalle, & ai media tools

Check out a 4 min video demo: [https://www.youtube.com/watch?v=kHuxGfGHqrw](https://www.youtube.com/watch?v=kHuxGfGHqrw)
Build your first website in minutes. A link in bio portfolio / socials list

Don't Learn to code. 
Learn to Prompt-gram. 
-for total beginners, no experience needed.
-start with classics like Hello world & Pong
-basic coding concepts re-imagined for post GPT-4 world

Learn prompt 1st media making.
Projects and tools to learn:
Prompt to ->
-> images
-> videos
-> audio
-> 3d assets
-> code

Explore brand new artistic mediums
-image to code & more!

Go full PRO
-Advanced Prompt to code tools.
-A full professional ai dev kit. Suitable for enterprise level, multimillion line, pre-existing codebases
-Using Cursor.sh, Github copilot & more
-Explore the frontier of ai codegen, and cast forbidden spells!


# Getting Started
1. Opening cmd menu with K
2. Use P to view starter project ideas
3. Upload a photo to turn it into a website
4. Ask anything!



## Credits:
Built by Mind Goblin Studios
[https://mindgoblinstudios.com/](https://mindgoblinstudios.com/)
Nick Dobos [https://www.x.com/NickADobos](https://www.x.com/NickADobos)


### GPTavern.md: Use KT to visit the Tavern & meet more GPTs!

Chat with all our members
[GPTavern website](https://gptavern.mindgoblinstudios.com/)

Featured Members:
Exec func 
Executive Function. Plan Step by Step. Reduce starting friction & resistance. 
[Executive Func](https://chat.openai.com/g/g-H93fevKeK-exec-func)

[Gif-PT](https://chat.openai.com/g/g-gbjSvXu6i-gif-pt)
Turn dalle images into gifs automatically

### HeyGPT + GPT & Me
A package of iOS shortcuts to connect with the openAi api!
- Double the speed you use chatGPT on iOS
- Use chatGPT directly in ANY iOS & Mac app
- Replace Siri's brain
- Create scheduled GPT notifications
- Only $1
Download now on gumroad
[https://nickdobos.gumroad.com/l/gptAndMe/](https://nickdobos.gumroad.com/l/gptAndMe/)

## Sign up for updates from Grimoire:
[https://grimoire.mindgoblinstudios.com/](https://grimoire.mindgoblinstudios.com/)

## Feedback
Send email the creator by tapping the Grimoire button at the top left of your screen and choosing Send Feedback.
Thanks!



## Support further development
## Toss a coin to your Grimoire!
[https://tipjar.mindgoblinstudios.com/](https://tipjar.mindgoblinstudios.com/)

# Lets get coding!
## Welcome to Grimoire & Prompt-gramming!

Remember:
Language is magic
That's why they call it SPELLing

-

K for cmd menu
P for project ideas
KT for GP-Tavern
PN for patch notes